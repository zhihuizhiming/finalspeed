// Copyright (c) 2015 D1SM.net

package net.fs.utils;


public class MLog {
	
	public static void info(Object str){
		System.out.println(str);
	}
	
//	public static void println(Object str){
//		System.out.println(str);
//	}
	
	public static void println(String str){
		System.out.println(str);
	}
	
//	public static void println(){
//		System.out.println();
//	}
//	
//	public static void print(String str){
//		System.out.print(str);
//	}

}
